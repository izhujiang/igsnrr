ICESat/GLAS and WGS-84 ellipsoid and geoid conversions
Terry Haran 20 May 2004
$Header: /NSIDC_CVS/FILES/tmh/glas/ellipsoid/README_ellipsoid.txt,v 1.10 2004/05/20 17:35:13 haran Exp $

This document is a README for several ICESat/GLAS IDL programs developed
at NSIDC to handle conversions between various ellipsoids and geoids.

Converting Latitudes and Elevations between Ellipsoids

Three programs convert latitudes and elevations between the WGS-84 and the
TOPEX/Poseidon ellipsoids. The latter ellipsoid is the ellipsoid used for
all ICESat/GLAS elevations.  See "How does the GLAS ellipsoid compare with
WGS84?" at http://nsidc.org/data/icesat/faq.html#p9 for more details.

  wgs2top.pro - this IDL procedure converts arrays of latitudes and
  elevations from the WGS-84 ellipsoid to the TOPEX/Poseidon ellipsoid.

  top2wgs.pro - this IDL procedure converts arrays of latitudes and
  elevations from the TOPEX/Poseidon ellipsoid to the WGS-84 ellipsoid.

  convert_ellipsoid.pro - this IDL procedure is called by wgs2top and
  top2wgs to actually perform the indicated ellipsoid conversions.

See the header in each file for the calling sequence and argument
specifications for each procedure.

Also included is a test script (test_ce.pro) that calls the above programs
for latitudes from -90 to +90 degrees at 1 degree intervals and produces
screen plots of the differences in latitude and elevation between the
different ellipsoids. The WGS-84 elevation was fixed at 3000 meters for
each WGS-84 latitude. The test script is invoked by typing @test_ce at the
IDL prompt. The screen plots have been captured in these gif files:

  test_ce_0_latitude_degrees.gif - this plot shows calculated TOPEX/Poseidon
  latitudes minus given WGS-84 latitudes as a function of the WGS-84
  latitudes. The minimum/maximum difference =~ -+1.23e-7 degrees at -+45
  degrees, respectively.

  test_ce_1_latitude_cm.gif - the same plot as in latitude_degrees.gif
  except that the difference in latitude has been converted to centimeters
  measured on the surface of an ellipsoid that is the "average" of the
  TOPEX/Poseideon and WGS-84 ellipsoids. The minimum/maximum difference =~
  -+1.37 cm at -+45 degrees, respectively. These differences would
  probably be considered negligible for most applications so that
  TOPEX/Poseidon latitudes could be considered equivalent to WGS-84
  latitudes.

  test_ce_2_elevation.gif - this plot shows calculated TOPEX/Poseidon
  elevation minus given WGS-84 elevation (3000 meters) in cm. The minimum
  difference = 70.0000 cm at the equator = the WGS-84 equatorial radius
  (awgs = 637813700.000 cm) minus the Topex/Poseidon equatorial radius
  (atop = 637813630.000 cm). The maximum difference = 71.3682 cm at the
  poles = the WGS-84 polar radius (bwgs = 635675231.4245 cm) minus the
  Topex/Poseidon polar radius (btop = 635675160.0563 cm). These
  differences would probably be considered significant for many
  applications. However, for latitudes north/south of +-40 degrees,
  respectively, many applications could simply assume that TOPEX/Poseidon
  elevations are 71 cm higher than WGS-84 elevations.

Converting Elevations between Ellipsoids

Since the demonstrated differences in latitude between these ellipsoids is
so small, it is possible to approximate the change in elevation between
ellipsoids for a particular latitude using an empirically-derived formula:

  delta_h = h2 - h1 =  -((a2 - a1) * cos(phi)^2 + (b2 - b1) * sin(phi)^2
    where
      phi is latitude.
      h1 and h2 are elevations for ellipsoids 1 and 2, respectively.
      a1 and a2 are equatorial radii of ellipsoids 1 and 2, respectively.
      b1 and b2 are polar radii of ellipsoids 1 and 2, respectively.

This formula greatly simplifies the calclulation of the change in
elevation compared to the exact method used in convert_ellipsoid.pro.
There are four IDL programs using this alternate approach:

  wgs2top_delta_h.pro - a function that, given a latitude in degrees,
  returns the value in meters that should be added to a WGS-84 elevation
  to obtain a TOPEX/Poseidon elevation.

  egm2wgs_delta_h.pro - a function that, given a latitude in degrees,
  returns the value in meters that should be added to a EGM96 ideal
  ellipsoid elevation (see Converting Geoid Elevations between Ellipsoids
  and Tide Systems below) to obtain a WGS-84 elevation.

  egm2top_delta_h.pro - a function that, given a latitude in degrees,
  returns the value in meters that should be added to a EGM96 ideal
  ellipsoid elevation to obtain a TOPEX/Poseidon elevation.

  compute_delta_h.pro - a function called by each of the above three
  functions that, given a latitude in degrees, actually computes the
  particular delta_h value.

The test script test_ce.pro mentioned above calls the first three of these
alternate functions and creates three additional screen plots captured in
these gif files:

  test_ce_3_std_vs_alt.gif - this plot shows the test_ce_2_elevation.gif
  plot (above) minus the differences in elevation computed using
  wgs2top_delta_h.pro. Note that the minimum difference is only -0.0012 cm
  and the maximum difference is 0.0000 cm. This demonstrates the validity
  of using the alternative formula.

  test_ce_4_egm2wgs_elev.gif - this plot shows calculated EGM96 ideal
  ellipsoid elevation minus given WGS-84 elevation in cm. The minimum
  difference = -54.0000 cm at the equator = the EGM96 ideal ellipsoid
  equatorial radius (aegm = 637813646.000 cm) minus the WGS-84 equatorial
  radius (awgs = 637813700.000 cm). The maximum difference = -50.7614 cm
  at the poles = the EGM96 ideal polar equatorial radius (begm =
  635675180.6631 cm) minus the WGS-84 polar radius (bwgs = 635675231.4245
  cm).

  test_ce_5_egm2top_elev.gif - this plot shows calculated EGM96 ideal
  ellipsoid elevation minus given TOPEX/Poseidon elevation in cm. The
  minimum difference = 16.0000 cm at the equator = the EGM96 ideal
  ellipsoid equatorial radius (aegm = 637813646.000 cm) minus the
  TOPEX/Poseidon equatorial radius (atop = 637813630.0000 cm). The maximum
  difference = 20.6068 cm at the poles = the EGM96 ideal polar equatorial
  radius (begm = 635675180.6631 cm) minus the TOPEX/Poseidon polar radius
  (btop = 635675160.0563 cm).

Converting Geoid Elevations between Ellipsoids and Tide Systems

ICESat/GLAS products use the EGM96 geoid for geoid height data. The EGM96
Document, Section 11, "The EGM96 geoid undulation with respect to the
WGS84 ellipsoid" (http://cddisa.gsfc.nasa.gov/926/egm96/doc/S11.HTML)
explains how to convert geoid height data between different tide systems,
and how geoid height data for the WGS-84 ellipsoid were
calculated. Implicit in the WGS84 discussion is the information needed to
convert geoid heights between ellipsoids as well.

Pre-release 16 ICESat/GLAS geoid height data were referenced to the WGS-84
ellipsoid in a tide-free system. This is the same ellipsoid and tide
system used to generate the data available on the NIMA web "WGS 84 EGM96
15-Minute Geoid Height File and Coefficient File"
(http://earth-info.nima.mil/GandG/wgsegm/egm96.html). Quoting from this
page:

  "The geoid undulations value are calculated by applying a correction
  term that converts a pseudo-height anomaly calculated at a point on the
  ellipsoid to a geoid undulation value. In addition, a correction term of
  -0.53 m is added to the prior result to obtain the geoid undulation with
  respect to the WGS 84 ellipsoid."

The -0.53 meters mentioned above is "zeta0," the zero degree height
anomaly, the calculation of which is covered in section 11.2 of the EGM96
Document. Two methods of calculating zeta0 are provided. These
methods are implemented in two IDL programs:

  zeta0.pro - a function that, given values for gm0 and u0, returns a
  value for zeta0 in meters using the formula:
    zeta0 = (gm_ideal - gm0) / (r * gamma) - (w_ideal - u0) / gamma
      where
        gm_ideal = 3.986004418e14 m^3/s^2
        w_ideal = 62636856.88 m^2/s^2
        r = 6371007.0 m
        gamma = 9.797645 m/s^2

   zeta0_alt.pro - a function that, given values for a and f (the
   equatorial radius and flattening, respectively, of the target
   ellipsoid), returns a value for zeta0 in meters using the formula:
    zeta0 = (a_ideal - a) * (f_ideal - f) / 3
      where
        a_ideal = the equatorial radius of the EGM96 ideal ellipsoid
                =  6378136.46 m
        f_ideal = flattening of the EMG96 ideal ellipsoid
                = 1 / 298.25765

The test script test_z0.pro (invoked by typing @test_z0 at an IDL
prompt) calls the above two functions using values for both the WGS-84
ellipsoid and the TOPEX/Poseidon ellipsoid. The WGS-84 gm0 and u0 values
are provided in section 11.2 of the EGM96 Document. The TOPEX/Poseidon gm0
and u0 values were provided in a document entitled GeoidFix2.doc
(converted to GeoidFix2.pdf and included here) from Dr. Nikos Pavlis.
The output from test_z0.pro is:

wgs: gm0: 3.986004418e+14  u0: 62636851.710  zeta0_0: -52.77 cm
top: gm1: 3.986004415e+14  u1: 62636858.570  zeta0_1:  17.73 cm
zeta0_1 - zeta0_0:  70.50 cm

wgs: a0: 6378137.0  1/f0: 298.257223563  zeta0_0_alt: -52.98 cm
top: a1: 6378136.3  1/f1: 298.257000000  zeta0_1_alt:  17.55 cm
zeta0_1_alt - zeta0_0_alt:  70.53 cm

Note that both of the above methods use a spherical approximation for the
ellipsoid which results in a single constant value for zeta0. In
addition, both methods appear to really be a conversion from the EGM96
ideal ellipsoid to the target ellipsoid (WGS-84 or TOPEX/Poseidon). I
propose a third method: define zeta0 as simply delta_h for a
conversion from the EGM96 ideal ellipsoid to to the target ellipsoid as a
variable function of latitude; hence the IDL functions egm2wgs_delta_h.pro
and egm2top_delta_h.pro mentioned above. Looking again at
test_ce_4_egm2wgs_elev.gif and test_ce_5_egm2top_elev.gif mentioned above,
we see that the range of delta_h values for each target ellipsoid are a
close match to the corresponding zeta0 values listed above.

The following IDL program can be used to convert geoid height values into
another set of a geoid height values relative to a different ellipsoid
and/or using a different tide system:

  convert_geoid.pro - a function that calculates an array of conversion
  values to add to an array of unconverted geoid height values to convert
  them into another set of geoid height values relative to a different
  ellipsoid and/or using a different tide system. The function performs
  the following calculation:
    total_conversion = -conversion_from_ellipsoid +
                        conversion_to_ellipsoid +
                        conversion_tide
  Both conversion_from_ellipsoid and conversion_to_ellipsoid can be
  specified as either single value zeta0 values, or can be variable
  delta_h values that are a function of latitude; conversion_tide values
  are always a function of latitude. See the header to convert_geoid.pro
  for more details on the calling procedure.

The test script test_cg.pro (invoked by typing @test_cg at an IDL prompt)
calls the above function using a variety of parameters, and produces plots
that have been saved as the following gif files:

  test_cg_0_wc2tc.gif - a plot using default values for specifying
  from_ellipsoid, to_ellipsoid, from_tide, and to_tide, namely:
    from_ellipsoid = -0.53 = constant WGS-84 zeta0 value in meters
    to_ellipsoid = 0.175 = constant TOPEX/Poseidon zeta0 value in
      meters
    from_tide = "tide-free"
    to_tide = "mean-tide"
  Thus this plot represents the values that must be added to ICESat/GLAS
  pre-release 16 WGS-84 tide-free geoid height values to obtain release 18 and
  later TOPEX/Poseidon mean-tide geoid height values. The effective
  formula used to generate this plot is:
    total_conversion = -conversion_from_ellipsoid +
                        conversion_to_ellipsoid +
                        conversion_tide
      where
        conversion_from_ellipsoid = -0.53 meters
        conversion_to_ellipsoid = 0.175 meters
        conversion_tide = 1.3 * (9.9 - 29.6 * sin(lat)^2) / 100 meters
  And to do the conversion:
    height_18 = height_pre16 + total_conversion
      where
        height_18 = release 18 and later TOPEX/Poseidon mean-tide geoid
          height values in meters
        height_pre16 = pre-release 16 WGS-84 tide-free geoid height values

  test_cg_1_wc2tv.gif - the same plot as test_cg_0_wc2tc.gif, except that
  to_ellipsoid has been changed from the single zeta0 value of 0.175
  to a two element array specifying the equatorial and polar radii,
  respectively, of the TOPEX/Poseidon ellipsoid to be used to calculate a
  variable zeta0 using compute_delta_h as a function of latitude:
    from_ellipsoid = -0.53 = constant WGS-84 zeta0 value in meters.
    to_ellipsoid = [6378136.300000, 6356751.600563] = [atop, btop]
    from_tide = "tide-free"
    to_tide = "mean-tide"
  Note that this plot is very similar to test_cg_0_wc2tc.gif, but
  presumably slightly more accurate, since the spherical approximation for
  the ellipsoid has been replaced with formula for the change in ellipsoid
  elevation as a function of latitude.

  test_cg_2_diff.gif - this plot is simply test_cg_1_wc2tv.gif minus
  test_cg_0_wctc.gif. Note that the difference ranges from -1.5 cm at the
  equator to 3.1068 cm at the poles.

  test_cg_3_tc2tv.gif - this plot is created by specifying a conversion
  from TOPEX/Poseidon mean-tide geoid heights using a constant zeta0
  value of 0.175 meters to TOPEX/Poseidon mean-tide geoid heights using a
  variable zeta0 as a function of latitude:
    from_ellipsoid = 0.175 = constant TOPEX/Poseidon zeta0 value in
      meters
    to_ellipsoid = [6378136.300000, 6356751.600563] = [atop, btop]
    from_tide = "mean-tide"
    to_tide = "mean-tide"
  Note that this is plot is identical to the previous plot, but uses a
  single call to convert_geoid.

Correcting the Geoid Height Parameter for Different Data Releases

Pre-release 16 ICESat/GLAS geoid height data were referenced to the WGS-84
ellipsoid in a tide-free system. The zero degree height anomaly used for
the WGS-84 ellipsoid was a constant value of -53.0 centimeters. In release 16
and release 17 data, an attempt was made to correct the geoid height data
so that it would be relative to the TOPEX/Poseidon ellipsoid in a
mean-tide system. The zero degree height anomaly used for the
TOPEX/Poseidon ellipsoid was a constant value of 18.1 centimeters. This value
appears to have been incorrectly calculated and should have been 17.5
centimeters. Moreover, the correction calculation failed to subtract out the
zero degree height anomaly for the WGS-84 ellipsoid, i.e. -53.0 centimeters.

The following IDL program can be used to correct geoid height values from
a particular data release so that the resulting values are relative to the
TOPEX/Poseidon ellipsoid, and are in a mean-tide system:

  correct_geoid_delta_h.pro - a function that calculates an array of
  correction values to add to an array of uncorrected geoid height values
  for a particular data release. Given an array of latitudes (phi) and a
  release number (release), the function performs the following
  calculation:
    delta_h = q0 + q1 * sin(phi)^2
    where
      delta_h is an array of values in centimeters that should be added to a
        corresponding array of geoid heights in centimeters at the
        corresponding latitudes indicated by phi for the indicated
        release.

      By default the release keyword is 14, and all values for which
      the release keyword is less than 16 are treated the same way.

      By default, the resulting values are relative to the TOPEX/Poseidon
      ellipsoid using a constant zero degree height anomaly of 17.5
      centimeters.  If the keyword variable_zeta0 is set, then the
      resulting values are relative to the TOPEX/Poseidon ellipsoid using
      a variable zero degree height anomaly that is a function of
      latitude.

      The values of q0 and q1 are determined as follows:
        If the keyword variable_zeta0 is not set, then
          If release is less than 16, then
            q0 = 83.37
            q1 = -38.48
          If release is greater than or equal to 16 and less than 18, then
            q0 = 52.40
            q1 = 0
          If release is 18 or higher, then
            q0 = 0
            q1 = 0
        If the keyword variable_zeta0 is set, then
          If release is less than 16, then
            q0 = 81.87
            q1 = -33.8732
          If release is greater than or equal to 16 and less than 18, then
            q0 = 50.90
            q1 = 4.6068
          If release is 18 or higher, then
            q0 = -1.5
            q1 = 4.6068

      See the comments in the REFERENCE section of the header in
      correct_geoid_delta_h.pro for the derivations of q0 and q1.
