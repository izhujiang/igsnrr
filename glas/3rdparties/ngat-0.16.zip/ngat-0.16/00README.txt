General Information
-------------------

This is the NSIDC GLAS Altimetry elevation extractor Tool (NGAT) version 0.16
This software is designed to allow users to extract elevation and geoid data
from GLAS altimetry products (GLA06,12,13,14,15).  Works on Release 12
through Release 34 data.

The NGAT is a freely distributed tool and is provided as is without any
warranties implied or stated. Copyright (C) 2006 University of Colorado.


Portions of the code distributed under the following license.
;-
; Copyright (C) 1997-2003, Craig Markwardt
; This software is provided as is without any warranty whatsoever.
; Permission to use, copy, modify, and distribute modified or
; unmodified copies is granted, provided this copyright and disclaimer
; are included unchanged.
;-

Contact Information:
User Services
National Snow and Ice Data Center
CIRES, 449 UCB
University of Colorado
Boulder, CO 80309-0449
Phone: +1 (303) 492-6199
Fax: +1 (303) 492-2468
E-mail: nsidc@nsidc.org


About the tool
--------------

The NGAT lets a user extract information from an ICESat/GLAS binary altimetry
file.  The information is presented in an easy to use column output format.

The output data look like this.

  372403915 03/07/2004 00:33:11.540  69.711446 209.602310     134.482       -0.220000
  372403915 03/07/2004 00:33:11.565  69.712961 209.601311     135.949       -0.225128
  372403915 03/07/2004 00:33:11.590  69.714476 209.600318     138.315       -0.230256
  372403915 03/07/2004 00:33:11.615  69.715991 209.599331     140.208       -0.235385

Columns are:

Record Number -  1 record (40 samples)
Date          -  MM/DD/YYYY
Time          -  HH:MM:SS.sss
Latitude      -  'i_lat' converted to degrees
Longitude     -  'i_lon' converted to degrees
elevation     -  the 'i_elev' field for the chosen product number, converted to meters
geoid	      -  the 'i_gdHt' values, interpolated for each shot also
                 converted to meters  

Please see the GLAS Altimetry Data Dictionary
(http://nsidc.org/data/docs/daac/glas_altimetry/data_dictionary.html) for
descriptions of 'i_lat', 'i_lon, 'i_elev', and 'i_gdHt'

Starting with Version 0.11, i_satElevCorr (or i_satRngCorr for Release
27 and lower data), i_gval_rcv, and i_UTCTime in decimal seconds to 3
decimal places (i.e. having 1 millisecond precision) can all be
appended to the list of output variables following the geoid field by
setting show_saturation_gain_corrections to a non-zero value in the
batch_read_altimetry.ini file.  Again, please see the GLAS Altimetry
Data Dictionary for further information about these variables.

Starting with Version 0.14, product variable i_deltaEllip, whose value
is Surface Elevation (T/P ellipsoid) minus Surface Elevation (WGS84
ellipsoid), can be retrieved. This product variable will be added to
the end of your output record if you set "show_delta_ellip" to a
non-zero value in the batch_read_altimetry.ini file. Note that this
product variable is only retrievable from release 33 and higher data
files.

Starting with Version 0.15, product variable i_GmC, whose value is the
difference in the transmit pulse gaussian fit and the centroid of the
transmit pulse, can be retrieved. This product variable will be added
to the end of your output record if you set "show_gmc" to a
non-zero value in the batch_read_altimetry.ini file. Note that this
product variable is only retrievable from release 34 and higher data
files.

Prerequisites
-------------

The NGAT runs under IDL (7.0 or greater) or the free IDLVM.  Please see RSI's
website for information on how to install the free IDL virtual machine:
http://www.harrisgeospatial.com/Support/HelpArticlesDetail/TabId/219/ArtMID/900/ArticleID/12395/The-IDL-Virtual-Machine.aspx

Installation
------------
No installation is required for the tool.  

Instructions
------------

The user needs to set up a batch_read_altimetry.ini file.  This contains the
input parameters for processing, such as, input/output directories,
input/output file names, product number, release number, starting record and
number of records to process.

Unix:

At the command line, in the directory containing the batch_read_altimetry.sav
file as well as the batch_read_altimetry.ini file type,

prompt> idl -vm="batch_read_altimetry.sav"

Windows:

make sure the batch_read_altimetry.ini is in the same directory as the
batch_read_altimetry.sav and just double click the batch_read_altimetry.sav
file.


A confirmation dialog should pop up to let you know processing has finished.



Manifest
--------

Your kit should contain the following files:

00README.txt - this file

batch_read_altimetry.sav - the binary code for the tool

batch_read_altimetry.ini - the sample file that configures the input/output
			   and product options

ReleaseNotes.txt - Inventory of product history.





